<?php

namespace App\Http\Controllers\Auth\Back;


class TestController extends Controller
{
     public function showForm()
    {
        echo "fgydyreytreyret";die;
      return view('back.auth.login');
    }
    
    
}